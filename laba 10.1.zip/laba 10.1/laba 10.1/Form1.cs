﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace laba_10._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                str = textBox1.Text;
                a = Convert.ToDouble(str);
                if (Convert.ToDouble(str) <= 0) { textBox1.Text = "Число должно быть положительным"; }
                else { a = Convert.ToInt32(str); flag1 = false; flag2 = false; }
            }
            catch (OverflowException)
            {
                flag1 = true;
            }
            catch (FormatException)
            {
                flag2 = true;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                str = textBox2.Text;
                b = Convert.ToDouble(str);
                if (Convert.ToDouble(str) <= 0) { textBox2.Text = "Число должно быть положительным"; }
                else { b = Convert.ToInt32(str); flag3 = false; flag4 = false; }
            }
            catch (OverflowException)
            {
                flag3 = true;
            }
            catch (FormatException)
            {
                flag4 = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                str = textBox3.Text;
                c = Convert.ToDouble(str);
                if (Convert.ToDouble(str) <= 0) { textBox3.Text = "Число должно быть положительным"; }
                else { c = Convert.ToInt32(str); flag5 = false; flag6 = false; }
            }
            catch (OverflowException)
            {
                flag5 = true;
            }
            catch (FormatException)
            {
                flag6 = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (((flag1 && flag2) || (flag1 && flag4) || (flag1 && flag6)) || ((flag3 && flag2) || (flag3 && flag4) || (flag3 && flag6)) || ((flag5 && flag2) || (flag5 && flag4) || (flag5 && flag6)))
            {
                label5.Text = "Неверный формат и Ошибка переполнения";
            }
            else if (flag1 || flag3 || flag5)
            {
                label5.Text = "Ошибка переполнения";
            }
            else if (flag2 || flag4 || flag6)
            {
                label5.Text = "Неверный формат";
            }
            else if (check(a, b, c))
            {
                label5.Text = "Треугольника с указанными сторонами";
                label6.Text = "не существует";
            }
            else
            {
                label5.Text = "P = " + Convert.ToString(find_p(a, b, c));
                label6.Text = "S = " + Convert.ToString(find_s(a, b, c));
            }
        }
        private double find_p(double a, double b, double c)
        {
            return a + b + c;
        }
        private double find_pp(double a, double b, double c)
        {
            return (a + b + c) / 2;
        }
        private double find_s(double a, double b, double c)
        {
            return Math.Sqrt(find_pp(a, b, c) * (find_pp(a, b, c) - a) * (find_pp(a, b, c) - b) * (find_pp(a, b, c) - c));
        }
        private bool check(double a, double b, double c)
        {
            if (a + b > c && a + c > b && b + c > a)
            {
                return false;
            }
            else { return true; }
        }

    }
}