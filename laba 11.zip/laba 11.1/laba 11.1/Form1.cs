﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba_11._1
{
    public partial class Form1 : Form
    {
        int n = 0;
        public Form1()
        {
            InitializeComponent();
        }

        
        private void trackBar2_Scroll_1(object sender, EventArgs e)
        {
            n = Convert.ToInt32(trackBar2.Value);
            label1.Text = "Значение n: " + n.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Text = Convert.ToString(Func1(n));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label6.Text = Convert.ToString(Func2(n));
        }
        private int Func1(int n)
        {
            if (n == 0) { return 1; }
            else { return (2 * n + 1) * (2 * n + 1) + Func1(n-1); }
        }
        private double Func2(double n)
        {
            double ans = (1.0 / 3.0) * (n + 1) * ((2 * n) + 1) * ((2 * n) + 3);
            return ans;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
