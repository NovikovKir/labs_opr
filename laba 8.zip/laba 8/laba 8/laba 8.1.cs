﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Triangle
{
    private double sideA;
    private double sideB;
    private double sideC;

    public Triangle(double a, double b, double c)
    {
        if (IsValidTriangle(a, b, c))
        {
            sideA = a;
            sideB = b;
            sideC = c;
        }
        else
        {
            throw new ArgumentException("Треугольник с такими сторонами не существует.");
        }
    }

    public double SideA
    {
        get { return sideA; }
        set
        {
            if (IsValidTriangle(value, sideB, sideC))
                sideA = value;
            else
                throw new ArgumentException("Треугольник с такими сторонами не существует.");
        }
    }

    public double SideB
    {
        get { return sideB; }
        set
        {
            if (IsValidTriangle(sideA, value, sideC))
                sideB = value;
            else
                throw new ArgumentException("Треугольник с такими сторонами не существует.");
        }
    }

    public double SideC
    {
        get { return sideC; }
        set
        {
            if (IsValidTriangle(sideA, sideB, value))
                sideC = value;
            else
                throw new ArgumentException("Треугольник с такими сторонами не существует.");
        }
    }

    public double Perimeter()
    {
        return sideA + sideB + sideC;
    }
    public double Area()
    {
        double s = Perimeter() / 2;
        return Math.Sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
    }
    public double AngleAB()
    {
        return (Math.Asin(2 * Area() / (sideA * sideB)) * (180 / Math.PI));
    }
    public double AngleAC()
    {
        return (Math.Asin(2 * Area() / (sideA * sideC)) * (180 / Math.PI));
    }
    public double AngleBC()
    {
        return (Math.Asin(2 * Area() / (sideB * sideC)) * (180 / Math.PI));
    }
    public double HeightA()
    {
        return 2 * Area() / sideA;
    }

    public double HeightB()
    {
        return 2 * Area() / sideB;
    }

    public double HeightC()
    {
        return 2 * Area() / sideC;
    }

    public string Type()
    {
        if (sideA == sideB && sideB == sideC)
            return "Равносторонний";
        else if (sideA == sideB || sideA == sideC || sideB == sideC)
            return "Равнобедренный";
        else if (Math.Pow(sideA, 2) == Math.Pow(sideB, 2) + Math.Pow(sideC, 2) ||
            Math.Pow(sideB, 2) == Math.Pow(sideA, 2) + Math.Pow(sideC, 2) ||
            Math.Pow(sideC, 2) == Math.Pow(sideA, 2) + Math.Pow(sideB, 2))
            return "Прямоугольный";
        else
            return "Обычный";
    }

    private bool IsValidTriangle(double a, double b, double c)
    {
        return a + b > c && a + c > b && b + c > a;
    }
}

namespace ОПР
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                double sideA, sideB, sideC;

                Console.WriteLine("Введите длину стороны A треугольника:");
                while (!double.TryParse(Console.ReadLine(), out sideA) || sideA <= 0)
                {
                    Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное число для стороны A:");
                }

                Console.WriteLine("Введите длину стороны B треугольника:");
                while (!double.TryParse(Console.ReadLine(), out sideB) || sideB <= 0)
                {
                    Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное число для стороны B:");
                }

                Console.WriteLine("Введите длину стороны C треугольника:");
                while (!double.TryParse(Console.ReadLine(), out sideC) || sideC <= 0)
                {
                    Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное число для стороны C:");
                }

                Triangle triangle = new Triangle(sideA, sideB, sideC);

                Console.WriteLine("Периметр треугольника: " + triangle.Perimeter());
                Console.WriteLine("Площадь треугольника: " + triangle.Area());
                Console.WriteLine("Угол между сторонами A и B: " + triangle.AngleAB());
                Console.WriteLine("Угол между сторонами A и C: " + triangle.AngleAC());
                Console.WriteLine("Угол между сторонами B и C: " + triangle.AngleBC());
                Console.WriteLine("Высота, опущенная на сторону A: " + triangle.HeightA());
                Console.WriteLine("Высота, опущенная на сторону B: " + triangle.HeightB());
                Console.WriteLine("Высота, опущенная на сторону C: " + triangle.HeightC());
                Console.WriteLine("Тип треугольника: " + triangle.Type());
            }
            catch (FormatException)
            {
                Console.WriteLine("Формат числа неправильный");
            }
            catch (OverflowException)
            {
                Console.WriteLine("Число недопустимо большое или недопустимо малое");
            }
        }
    }
}*/