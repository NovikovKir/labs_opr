﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace laba_11._1
{
    public partial class Form2 : Form
    {
        List<Price> prices = new List<Price>(10);
        List<string> products = new List<string> { "Хлеб", "Молоко", "Масло", "Сыр", "Огурец", "Помидор", "Колбаса", "Майонез", "Кетчуп", "Пудж" };
        List<string> shops = new List<string> { "Ярче", "Interspar", "Spar", "Абрикос", "Мария-ра", "Подберезовик", "Лента", "Магнит", "Пятерочка", "Бристоль" };
        public Form2()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    listBox2.Items.Clear();
                    listBox2.Items.Add("Ничего не выбрано");
                }
                else
                {
                    string text = textBox1.Text;
                    if (products.Contains(text))
                    {
                        listBox2.Items.Clear();
                        foreach (Price param in prices.OrderBy(w => w.shop_name))
                            if (text == param.prod_name)
                                listBox2.Items.Add($"Магазин: {param.shop_name}, Цена: {param.prod_cost} рублей");
                    }
                    else
                    {
                        listBox2.Items.Clear();
                        listBox2.Items.Add("Такого продукта нет");
                    }
                }
            }
            catch (FormatException)
            {
                listBox2.Items.Clear();
                listBox2.Items.Add("Неверный формат");
            }
            catch (OverflowException)
            {
                listBox2.Items.Clear();
                listBox2.Items.Add("Ошибка переполнения");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Random random = new Random();

            using (StreamWriter writer = new StreamWriter("spisok.txt"))
            {
                for (int i = 0; i < 10; i++)
                {
                    writer.WriteLineAsync($"{products[random.Next(0, products.Count())]}");
                    writer.WriteLineAsync($"{shops[random.Next(0, shops.Count())]}");
                    writer.WriteLineAsync($"{random.Next(100, 1000)}");
                }
            }
            using (StreamReader reader = new StreamReader("spisok.txt"))
            {
                for (int i = 0; i < 31; i++)
                    prices.Add(new Price(reader.ReadLine(), reader.ReadLine(), Convert.ToInt32(reader.ReadLine())));
            }
            foreach (string param in products)
            {
                listBox1.Items.Add(param);
            }
        }
    }
    class Price
    {
        public string prod_name { get; set; }
        public string shop_name { get; set; }
        public int prod_cost { get; set; }
        public string Con_str()
        {
            return $"{prod_name};{shop_name};{prod_cost}";
        }
        public Price(string prod, string shop, int cost)
        {
            this.prod_name = prod;
            this.shop_name = shop;
            this.prod_cost = cost;
        }
    }
}
