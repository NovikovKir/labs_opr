﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class BitString
{
    private ulong bits1;
    private ulong bits2;

    public BitString(ulong bits1, ulong bits2)
    {
        this.bits1 = bits1;
        this.bits2 = bits2;
    }

    public ulong Bits1
    {
        get { return bits1; }
        set { bits1 = value; }
    }

    public ulong Bits2
    {
        get { return bits2; }
        set { bits2 = value; }
    }

    public BitString And(BitString other)
    {
        return new BitString(this.bits1 & other.bits1, this.bits2 & other.bits2);
    }

    public BitString Or(BitString other)
    {
        return new BitString(this.bits1 | other.bits1, this.bits2 | other.bits2);
    }

    public BitString Xor(BitString other)
    {
        return new BitString(this.bits1 ^ other.bits1, this.bits2 ^ other.bits2);
    }

    public BitString Not()
    {
        return new BitString(~this.bits1, ~this.bits2);
    }

    public BitString ShiftLeft(int bits)
    {
        return new BitString(this.bits1 << bits, this.bits2 << bits);
    }

    public BitString ShiftRight(int bits)
    {
        return new BitString(this.bits1 >> bits, this.bits2 >> bits);
    }

    public override string ToString()
    {
        return $"Bits1: {Convert.ToString((long)this.bits1, 2)}, Bits2: {Convert.ToString((long)this.bits2, 2)}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        ulong bits1, bits2;

        Console.WriteLine("Введите high 64-битное число:");
        while (!ulong.TryParse(Console.ReadLine(), out bits1))
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное 64-битное число:");
        }

        Console.WriteLine("Введите low 64-битное число:");
        while (!ulong.TryParse(Console.ReadLine(), out bits2))
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное 64-битное число:");
        }


        BitString bs1 = new BitString(bits1, bits2);

        Console.WriteLine("Введите high: ");
        while (!ulong.TryParse(Console.ReadLine(), out bits1))
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное 64-битное число:");
        }

        Console.WriteLine("Введите low: ");
        while (!ulong.TryParse(Console.ReadLine(), out bits2))
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное 64-битное число:");
        }

        BitString bs2 = new BitString(bits1, bits2);

        Console.WriteLine("bs1: " + bs1);
        Console.WriteLine("bs2: " + bs2);
        Console.WriteLine("bs1 AND bs2: " + bs1.And(bs2));
        Console.WriteLine("bs1 OR bs2: " + bs1.Or(bs2));
        Console.WriteLine("bs1 XOR bs2: " + bs1.Xor(bs2));
        Console.WriteLine("NOT bs1: " + bs1.Not());
        Console.WriteLine("bs1 shift left 2 bits: " + bs1.ShiftLeft(2));
        Console.WriteLine("bs1 shift right 2 bits: " + bs1.ShiftRight(2));
    }
}*/