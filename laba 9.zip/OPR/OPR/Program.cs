﻿using System;
using System.IO;

abstract class Document
{
    protected string filePath;

    public Document(string filePath)
    {
        this.filePath = filePath;
    }

    public abstract Document Copy(string newPath);

    public void Move(string newPath)
    {
        File.Move(filePath, newPath);
        Console.WriteLine($"Документ перемещен в {newPath}");
        filePath = newPath;
    }

    public void Delete()
    {
        File.Delete(filePath);
        Console.WriteLine("Документ удален");
    }

    public abstract string GetContent();

    public void FillContent(string newContent)
    {
        File.WriteAllText(filePath, newContent);
    }

    ~Document()
    {
        Console.WriteLine("Документ удален");
    }
}

class TextDocument : Document
{
    public TextDocument(string filePath) : base(filePath)
    {
    }

    public override Document Copy(string newPath)
    {
        File.Copy(filePath, newPath);
        Console.WriteLine("Копия документа создана.");
        return new TextDocument(newPath);
    }

    public override string GetContent()
    {
        return File.ReadAllText(filePath);
    }
}

class EncryptedTextDocument : Document
{
    private int shift;

    public EncryptedTextDocument(string filePath, int shift) : base(filePath)
    {
        this.shift = shift;
    }

    public override Document Copy(string newPath)
    {
        File.Copy(filePath, newPath);
        Console.WriteLine("Копия шифрованного документа создана.");
        return new EncryptedTextDocument(newPath, shift);
    }

    public override string GetContent()
    {
        string encryptedContent = File.ReadAllText(filePath);
        return Decrypt(encryptedContent, shift);
    }
    private string Decrypt(string input, int shift)
    {
        char[] chars = input.ToCharArray();
        for (int i = 0; i < chars.Length; i++)
        {
            char c = chars[i];
            if (char.IsLetter(c))
            {
                int offset = char.IsUpper(c) ? 'A' : 'a';
                chars[i] = (char)(((c + shift - offset) % 26) + offset);
            }
        }
        return new string(chars);
    }
}

internal class Program
{
    static void Main(string[] args)
    {
        try
        {
            // Создание обычного текстового документа
            //string filePath = "C:\\Users\\Кирилл\\Desktop\\9lab.txt";
            Console.WriteLine("Введите имя пути");
            string filePath = Console.ReadLine();
            var textDocument = new TextDocument(filePath);

            // Заполнение документа
            textDocument.FillContent("anekdot");

            // Получаем содержимое документа и выводим его
            string content = textDocument.GetContent();
            Console.Write("Содержимое текстового документа:");
            Console.WriteLine(content);

            // Копия документа
            Document copyDocument = textDocument.Copy("C:\\Users\\Кирилл\\Desktop\\9labb_copy.txt");

            // Перемещение документа
            textDocument.Move("D:Уник\\ОПр\\9laba\\9lab.txt");
            // Удаление документа
            textDocument.Delete();
            copyDocument.Delete();

            // Создание шифрованного текстового документа с шифром Цезаря (сдвиг на 3 символа)
            Console.WriteLine("Введите имя пути");
            string encryptedTextFilePath = Console.ReadLine();
            //string encryptedTextFilePath = "C:\\Users\\Кирилл\\Desktop\\9laba_encr.txt";
            var encryptedTextDocument = new EncryptedTextDocument(encryptedTextFilePath, 3);
            // Заполнение содержимого шифрованного документа
            encryptedTextDocument.FillContent("pl jklf slrbq pxqxkx");

            // Получение и вывод содержимого шифрованного текстового документа
            string encryptedContent = encryptedTextDocument.GetContent();
            Console.WriteLine("Содержимое зашифрованного текстового документа:");
            Console.WriteLine(encryptedContent);

            // Копия зашифрованного документа
            Document copyEncryptedDocument = encryptedTextDocument.Copy("C:\\Users\\Кирилл\\Desktop\\9laba_encr_copy.txt");

            // Перемещение зашифрованного документа
            encryptedTextDocument.Move("D:Уник\\ОПр\\9laba\\9laba_encr.txt");

            // Удаление зашифрованного документа
            encryptedTextDocument.Delete();
            copyEncryptedDocument.Delete();

            Console.ReadKey();
        }
        catch (ArgumentException) { Console.WriteLine("Неверное имя пути"); }
    }
}