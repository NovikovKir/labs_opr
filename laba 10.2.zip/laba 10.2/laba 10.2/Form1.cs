﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba10._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                s = textBox1.Text;
                if (Convert.ToInt32(s) <= 0) { textBox1.Text = "Число должно быть положительным"; }
                else { n = Convert.ToInt32(s); flag1 = false; flag2 = false; }
            }
            catch (OverflowException)
            {
                flag1 = true;
            }
            catch (FormatException)
            {
                flag2 = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (flag1) { label5.Text = "Ошибка переполнения"; }
            else if (flag2) { label5.Text = "Неверный формат"; }
            else { label5.Text = Convert.ToString(Func1(n)); }
        }

        private int Func1(int n)
        {
            if (n == 1) { return 1; }
            else { return (2 * n - 1) * (2 * n - 1) * (2 * n - 1) + Func1(n - 1); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (flag1) { label6.Text = "Ошибка переполнения"; }
            else if (flag2) { label6.Text = "Неверный формат"; }
            else { label6.Text = Convert.ToString(Func2(n)); }
        }

        private int Func2(int n)
        {
            return ((n * n * (2 * n * n - 1)));
        }
    }
}